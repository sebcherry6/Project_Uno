﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Project_Uno2;
using System;
using System.Collections.Generic;

public class Dna
{
    public Vector2 _position;
    public Vector2 _velocity;

    public SimpleAnimator _dnaAnim;

    public Rectangle _hitbox;
    public Texture2D _texture;

    public float _speed;

    public bool _collected;

    private string currentAnimation = "Idle";

    public Dna(Texture2D texture, Vector2 startPosition, float speed, Player player, Dictionary<string, List<Rectangle>> animations, double walkSpeed = 0.3)
    {
        _texture = texture;
        _position = startPosition;
        _speed = speed;
        _dnaAnim = new SimpleAnimator(texture);

        foreach (var animation in animations)
        {
            _dnaAnim.AddAnimation(animation.Key, animation.Value, walkSpeed);
        }
        _dnaAnim.Play("Idle");
    }

    public void Update(GameTime gameTime, Player player)
    {
        if (!_collected && player._hitbox.Intersects(_hitbox))
        {
            _collected = true;
            player._dnaCount++;
        }
        _dnaAnim.Update(gameTime);
        _hitbox = new Rectangle((int)_position.X, (int)_position.Y - 32, _dnaAnim._currentFrame.Width, _dnaAnim._currentFrame.Height);
    }

    public void Draw(SpriteBatch spriteBatch)
    {
        if (!_collected)
        {
            _dnaAnim.Draw(spriteBatch, new Vector2(_position.X, _position.Y - 64), SpriteEffects.None, Color.White);
        }
    }
}